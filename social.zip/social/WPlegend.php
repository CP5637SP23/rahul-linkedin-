<?php
/**
* @package WPlegend
*/
/*
plugin name: WPlegend
plugin URI:www.myplugin.com
Description: Redirect to a page.
version: 1.0
Author: rahulyenugula
Author URI:www.rahulyenugula/plugins.com
License: GPLv2 or later
Text domain: WP legend


WPlegend is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.

WPlegend is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with WPlegend. If not, see {License URI}.
*/



defined('ABSPATH') or die('wrong person');


add_action( 'wp_head', 'Social' );

function Social() {
  $info = '<a href="https://www.linkedin.com/"
 target="_blank" class="linkedin">
 <img src="'.plugins_url( "social/assets/linkedin.png"  ).'" alt="linkedin" height="40px", width="40px">

</a>';
echo $info;
}

// Register style sheet.
add_action( 'wp_enqueue_scripts', 'myplugin' );

/**
 * Register style sheet.
 */
function myplugin() {
  wp_register_style( 'myplugin-style', plugins_url( 'social/assets/css/plugin.css' ) );
  wp_enqueue_style( 'myplugin-style' );
}
